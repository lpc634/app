from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from src.models.user import User, Notification, db
from src.routes.notifications import send_push_notification_to_multiple
import atexit

scheduler = BackgroundScheduler()

def send_weekly_availability_reminder():
    """Send weekly reminder to all agents to update their availability."""
    try:
        # Get all agents
        agents = User.query.filter_by(role='agent').all()
        agent_ids = [agent.id for agent in agents]
        
        if not agent_ids:
            print("No agents found for weekly reminder")
            return
        
        title = "Weekly Availability Update"
        message = "Please update your availability status for the coming week."
        
        # Send push notifications
        result = send_push_notification_to_multiple(
            user_ids=agent_ids,
            title=title,
            message=message,
            notification_type='reminder'
        )
        
        print(f"Weekly reminder sent to {len(agent_ids)} agents. Success: {result.get('success', 0)}, Failed: {result.get('failure', 0)}")
        
    except Exception as e:
        print(f"Error sending weekly reminder: {str(e)}")

def init_scheduler(app):
    """Initialize the scheduler with the Flask app context."""
    
    def send_reminder_with_context():
        """Wrapper to send reminder within Flask app context."""
        with app.app_context():
            send_weekly_availability_reminder()
    
    # Schedule weekly reminder for Sunday at 6 PM
    scheduler.add_job(
        func=send_reminder_with_context,
        trigger=CronTrigger(day_of_week='sun', hour=18, minute=0),
        id='weekly_availability_reminder',
        name='Send weekly availability reminder to agents',
        replace_existing=True
    )
    
    # Start the scheduler
    scheduler.start()
    
    # Shut down the scheduler when exiting the app
    atexit.register(lambda: scheduler.shutdown())
    
    print("Scheduler initialized. Weekly reminders will be sent on Sundays at 6 PM.")

def get_scheduler_status():
    """Get the current status of scheduled jobs."""
    jobs = scheduler.get_jobs()
    return {
        'running': scheduler.running,
        'jobs': [
            {
                'id': job.id,
                'name': job.name,
                'next_run_time': job.next_run_time.isoformat() if job.next_run_time else None,
                'trigger': str(job.trigger)
            }
            for job in jobs
        ]
    }

