import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useAuth } from '@/hooks/useAuth'
import { useToast } from '@/hooks/use-toast'
import { 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Clock,
  Plus,
  Edit,
  Save,
  X
} from 'lucide-react'

export default function AvailabilityPage() {
  const [availability, setAvailability] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingDate, setEditingDate] = useState(null)
  const [editNotes, setEditNotes] = useState('')
  const { user, apiCall } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    fetchAvailability()
  }, [])

  const fetchAvailability = async () => {
    try {
      setLoading(true)
      const today = new Date()
      const endDate = new Date(today)
      endDate.setDate(today.getDate() + 14) // Next 2 weeks

      const data = await apiCall(`/availability/${user.id}?start_date=${today.toISOString().split('T')[0]}&end_date=${endDate.toISOString().split('T')[0]}`)
      setAvailability(data.availability || [])
    } catch (error) {
      console.error('Availability error:', error)
    } finally {
      setLoading(false)
    }
  }

  const toggleAvailability = async (date) => {
    try {
      const existingAvailability = availability.find(a => a.date === date)
      const newStatus = !existingAvailability?.is_available

      await apiCall('/availability', {
        method: 'POST',
        body: JSON.stringify({
          agent_id: user.id,
          start_date: date,
          end_date: date,
          is_available: newStatus
        })
      })

      toast({
        title: "Availability Updated",
        description: `You are now ${newStatus ? 'available' : 'unavailable'} for ${new Date(date).toLocaleDateString()}`,
      })

      fetchAvailability()
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to update availability",
        variant: "destructive",
      })
    }
  }

  const updateNotes = async (availabilityId, notes) => {
    try {
      await apiCall(`/availability/${availabilityId}`, {
        method: 'PUT',
        body: JSON.stringify({ notes })
      })

      toast({
        title: "Notes Updated",
        description: "Your availability notes have been saved",
      })

      setEditingDate(null)
      setEditNotes('')
      fetchAvailability()
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to update notes",
        variant: "destructive",
      })
    }
  }

  const getNext14Days = () => {
    const days = []
    const today = new Date()
    
    for (let i = 0; i < 14; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      days.push(date.toISOString().split('T')[0])
    }
    
    return days
  }

  const getAvailabilityForDate = (date) => {
    return availability.find(a => a.date === date)
  }

  const getStatusBadge = (isAvailable, isAway) => {
    if (isAway) {
      return (
        <Badge variant="destructive" className="flex items-center gap-1">
          <XCircle className="h-3 w-3" />
          Away
        </Badge>
      )
    }
    
    if (isAvailable) {
      return (
        <Badge variant="default" className="flex items-center gap-1 bg-green-500">
          <CheckCircle className="h-3 w-3" />
          Available
        </Badge>
      )
    }
    
    return (
      <Badge variant="secondary" className="flex items-center gap-1">
        <XCircle className="h-3 w-3" />
        Unavailable
      </Badge>
    )
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <div className="h-8 w-48 bg-muted animate-pulse rounded"></div>
          <div className="h-4 w-64 bg-muted animate-pulse rounded"></div>
        </div>
        <div className="grid gap-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="h-4 w-1/2 bg-muted animate-pulse rounded"></div>
                  <div className="h-3 w-2/3 bg-muted animate-pulse rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold tracking-tight">Availability Management</h1>
        <p className="text-muted-foreground">
          Manage your availability for the next 2 weeks
        </p>
      </div>

      {/* Quick Toggle for Today */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Today's Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="font-medium">
                {new Date().toLocaleDateString('en-GB', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
              <p className="text-sm text-muted-foreground">
                Quick toggle for today's availability
              </p>
            </div>
            <Button 
              onClick={() => toggleAvailability(new Date().toISOString().split('T')[0])}
              variant={getAvailabilityForDate(new Date().toISOString().split('T')[0])?.is_available ? 'destructive' : 'default'}
            >
              {getAvailabilityForDate(new Date().toISOString().split('T')[0])?.is_available ? 'Mark Unavailable' : 'Mark Available'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Availability Calendar */}
      <Card>
        <CardHeader>
          <CardTitle>Next 14 Days</CardTitle>
          <CardDescription>
            Set your availability for upcoming dates
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {getNext14Days().map((date) => {
              const dateObj = new Date(date)
              const availabilityData = getAvailabilityForDate(date)
              const isToday = date === new Date().toISOString().split('T')[0]
              const isPast = dateObj < new Date().setHours(0, 0, 0, 0)
              
              return (
                <div key={date} className={`p-4 border rounded-lg ${isToday ? 'border-primary bg-primary/5' : ''}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="space-y-1">
                      <p className="font-medium">
                        {dateObj.toLocaleDateString('en-GB', { 
                          weekday: 'long', 
                          month: 'short', 
                          day: 'numeric' 
                        })}
                        {isToday && <span className="text-primary ml-2">(Today)</span>}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {dateObj.toLocaleDateString('en-GB')}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(availabilityData?.is_available, availabilityData?.is_away)}
                      {!isPast && (
                        <Switch
                          checked={availabilityData?.is_available || false}
                          onCheckedChange={() => toggleAvailability(date)}
                          disabled={availabilityData?.is_away}
                        />
                      )}
                    </div>
                  </div>
                  
                  {availabilityData && (
                    <div className="space-y-2">
                      {editingDate === date ? (
                        <div className="space-y-2">
                          <Textarea
                            value={editNotes}
                            onChange={(e) => setEditNotes(e.target.value)}
                            placeholder="Add notes about your availability..."
                            className="min-h-[60px]"
                          />
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              onClick={() => updateNotes(availabilityData.id, editNotes)}
                            >
                              <Save className="h-4 w-4 mr-1" />
                              Save
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setEditingDate(null)
                                setEditNotes('')
                              }}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            {availabilityData.notes ? (
                              <p className="text-sm text-muted-foreground">
                                {availabilityData.notes}
                              </p>
                            ) : (
                              <p className="text-sm text-muted-foreground italic">
                                No notes added
                              </p>
                            )}
                          </div>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => {
                              setEditingDate(date)
                              setEditNotes(availabilityData.notes || '')
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Weekly Reminder Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Weekly Reminder
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm">
              You'll receive a reminder every Sunday at 6 PM to update your availability for the coming week.
            </p>
            <p className="text-xs text-muted-foreground">
              Make sure to keep your availability up to date so you don't miss out on job opportunities!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

