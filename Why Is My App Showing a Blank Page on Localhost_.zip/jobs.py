from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, Job, JobAssignment, AgentAvailability, Notification, db
from datetime import datetime, date
from dateutil.parser import parse

jobs_bp = Blueprint('jobs', __name__)

def require_admin():
    """Ensure user is an admin."""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    if not user or user.role != 'admin':
        return None
    return user

def require_agent_or_admin():
    """Ensure user is an agent or admin."""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    return user

@jobs_bp.route('/jobs', methods=['GET'])
@jwt_required()
def get_jobs():
    """Get list of jobs (filtered by role)."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get query parameters
        status = request.args.get('status')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Build query
        query = Job.query
        
        # Filter by status if provided
        if status:
            query = query.filter(Job.status == status)
        
        # Filter by date range if provided
        if start_date:
            start_date = parse(start_date)
            query = query.filter(Job.arrival_time >= start_date)
        
        if end_date:
            end_date = parse(end_date)
            query = query.filter(Job.arrival_time <= end_date)
        
        # For agents, only show jobs they're assigned to or available jobs
        if current_user.role == 'agent':
            # Get jobs where agent is assigned or jobs that are open
            assigned_jobs = query.join(JobAssignment).filter(
                JobAssignment.agent_id == current_user.id
            )
            
            # Get open jobs for dates when agent is available
            available_dates = db.session.query(AgentAvailability.date).filter(
                AgentAvailability.agent_id == current_user.id,
                AgentAvailability.is_available == True,
                AgentAvailability.is_away == False
            ).subquery()
            
            open_jobs = query.filter(
                Job.status == 'open',
                db.func.date(Job.arrival_time).in_(available_dates)
            )
            
            # Combine queries
            jobs = assigned_jobs.union(open_jobs).order_by(Job.arrival_time.desc()).all()
        else:
            # Admins see all jobs
            jobs = query.order_by(Job.arrival_time.desc()).all()
        
        return jsonify({
            'jobs': [job.to_dict() for job in jobs]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@jobs_bp.route('/jobs', methods=['POST'])
@jwt_required()
def create_job():
    """Create new job (admin only)."""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'job_type', 'address', 'arrival_time', 'agents_required']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Parse arrival time
        arrival_time = parse(data['arrival_time'])
        
        # Create job
        job = Job(
            title=data['title'],
            job_type=data['job_type'],
            address=data['address'],
            postcode=data.get('postcode'),
            arrival_time=arrival_time,
            agents_required=data['agents_required'],
            lead_agent_name=data.get('lead_agent_name'),
            instructions=data.get('instructions'),
            urgency_level=data.get('urgency_level', 'Standard'),
            created_by=current_user.id
        )
        
        db.session.add(job)
        db.session.commit()
        
        # Find eligible agents and send notifications
        job_date = arrival_time.date()
        eligible_agents = db.session.query(User).join(AgentAvailability).filter(
            User.role == 'agent',
            AgentAvailability.date == job_date,
            AgentAvailability.is_available == True,
            AgentAvailability.is_away == False
        ).all()
        
        # Create job assignments for eligible agents
        for agent in eligible_agents:
            assignment = JobAssignment(
                job_id=job.id,
                agent_id=agent.id,
                status='pending'
            )
            db.session.add(assignment)
            
            # Create notification
            notification = Notification(
                user_id=agent.id,
                title=f"New Job Available: {job.title}",
                message=f"Job Type: {job.job_type}\nAddress: {job.address}\nArrival: {job.arrival_time.strftime('%Y-%m-%d %H:%M')}\nAgents Required: {job.agents_required}",
                type='job_offer',
                job_id=job.id
            )
            db.session.add(notification)
        
        db.session.commit()
        
        # TODO: Send push notifications to eligible agents
        
        return jsonify({
            'message': 'Job created successfully',
            'job': job.to_dict(),
            'eligible_agents': len(eligible_agents)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@jobs_bp.route('/jobs/<int:job_id>', methods=['GET'])
@jwt_required()
def get_job(job_id):
    """Get job details."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        job = Job.query.get_or_404(job_id)
        
        # For agents, check if they have access to this job
        if current_user.role == 'agent':
            assignment = JobAssignment.query.filter_by(
                job_id=job_id,
                agent_id=current_user.id
            ).first()
            
            if not assignment and job.status != 'open':
                return jsonify({'error': 'Access denied'}), 403
        
        return jsonify({'job': job.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@jobs_bp.route('/jobs/<int:job_id>', methods=['PUT'])
@jwt_required()
def update_job(job_id):
    """Update job (admin only)."""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Access denied'}), 403
        
        job = Job.query.get_or_404(job_id)
        data = request.get_json()
        
        # Update fields
        updatable_fields = ['title', 'job_type', 'address', 'postcode', 'arrival_time', 
                           'agents_required', 'lead_agent_name', 'instructions', 
                           'urgency_level', 'status']
        
        for field in updatable_fields:
            if field in data:
                if field == 'arrival_time':
                    setattr(job, field, parse(data[field]))
                else:
                    setattr(job, field, data[field])
        
        job.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Job updated successfully',
            'job': job.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@jobs_bp.route('/jobs/<int:job_id>', methods=['DELETE'])
@jwt_required()
def delete_job(job_id):
    """Cancel job (admin only)."""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Access denied'}), 403
        
        job = Job.query.get_or_404(job_id)
        job.status = 'cancelled'
        job.updated_at = datetime.utcnow()
        
        # Notify all assigned agents
        assignments = JobAssignment.query.filter_by(job_id=job_id).all()
        for assignment in assignments:
            notification = Notification(
                user_id=assignment.agent_id,
                title=f"Job Cancelled: {job.title}",
                message=f"The job scheduled for {job.arrival_time.strftime('%Y-%m-%d %H:%M')} has been cancelled.",
                type='job_cancelled',
                job_id=job.id
            )
            db.session.add(notification)
        
        db.session.commit()
        
        return jsonify({'message': 'Job cancelled successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@jobs_bp.route('/jobs/<int:job_id>/respond', methods=['POST'])
@jwt_required()
def respond_to_job(job_id):
    """Agent response (accept/decline)."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        if current_user.role != 'agent':
            return jsonify({'error': 'Only agents can respond to jobs'}), 403
        
        data = request.get_json()
        response = data.get('response')  # 'accepted' or 'declined'
        
        if response not in ['accepted', 'declined']:
            return jsonify({'error': 'Response must be "accepted" or "declined"'}), 400
        
        # Find the assignment
        assignment = JobAssignment.query.filter_by(
            job_id=job_id,
            agent_id=current_user.id
        ).first()
        
        if not assignment:
            return jsonify({'error': 'Job assignment not found'}), 404
        
        if assignment.status != 'pending':
            return jsonify({'error': 'Job has already been responded to'}), 400
        
        # Update assignment
        assignment.status = response
        assignment.response_time = datetime.utcnow()
        
        job = Job.query.get(job_id)
        
        if response == 'accepted':
            # Check if job is still open and has space
            accepted_count = JobAssignment.query.filter_by(
                job_id=job_id,
                status='accepted'
            ).count()
            
            if accepted_count >= job.agents_required:
                return jsonify({'error': 'Job is already full'}), 400
            
            # Auto-deactivate agent for the rest of the day
            job_date = job.arrival_time.date()
            availability = AgentAvailability.query.filter_by(
                agent_id=current_user.id,
                date=job_date
            ).first()
            
            if availability:
                availability.is_available = False
                availability.notes = f"Auto-deactivated after accepting job: {job.title}"
                availability.updated_at = datetime.utcnow()
            
            # Create confirmation notification
            notification = Notification(
                user_id=current_user.id,
                title=f"Job Confirmed: {job.title}",
                message=f"You're confirmed for {job.title}\nAddress: {job.address}\nArrival: {job.arrival_time.strftime('%Y-%m-%d %H:%M')}\nLead Agent: {job.lead_agent_name or 'TBD'}\nInstructions: {job.instructions or 'None'}",
                type='job_confirmation',
                job_id=job.id
            )
            db.session.add(notification)
            
            # Check if job is now full
            new_accepted_count = accepted_count + 1
            if new_accepted_count >= job.agents_required:
                job.status = 'filled'
                
                # Notify all other pending agents that job is filled
                pending_assignments = JobAssignment.query.filter_by(
                    job_id=job_id,
                    status='pending'
                ).all()
                
                for pending in pending_assignments:
                    notification = Notification(
                        user_id=pending.agent_id,
                        title=f"Job Filled: {job.title}",
                        message=f"The job scheduled for {job.arrival_time.strftime('%Y-%m-%d %H:%M')} has now been filled. No further action needed.",
                        type='job_filled',
                        job_id=job.id
                    )
                    db.session.add(notification)
        
        db.session.commit()
        
        return jsonify({
            'message': f'Job {response} successfully',
            'assignment': assignment.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@jobs_bp.route('/assignments/agent/<int:agent_id>', methods=['GET'])
@jwt_required()
def get_agent_assignments(agent_id):
    """Get agent's assignments."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Agents can only view their own assignments, admins can view any
        if current_user.role == 'agent' and current_user.id != agent_id:
            return jsonify({'error': 'Access denied'}), 403
        
        # Get query parameters
        status = request.args.get('status')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Build query
        query = JobAssignment.query.filter_by(agent_id=agent_id)
        
        if status:
            query = query.filter(JobAssignment.status == status)
        
        # Join with Job for date filtering
        if start_date or end_date:
            query = query.join(Job)
            
            if start_date:
                start_date = parse(start_date)
                query = query.filter(Job.arrival_time >= start_date)
            
            if end_date:
                end_date = parse(end_date)
                query = query.filter(Job.arrival_time <= end_date)
        
        assignments = query.order_by(JobAssignment.created_at.desc()).all()
        
        return jsonify({
            'agent_id': agent_id,
            'assignments': [assignment.to_dict() for assignment in assignments]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

