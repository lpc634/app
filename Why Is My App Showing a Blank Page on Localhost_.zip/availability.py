from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, AgentAvailability, db
from datetime import datetime, date, timedelta
from dateutil.parser import parse

availability_bp = Blueprint('availability', __name__)

def require_agent_or_admin():
    """Decorator to ensure user is an agent or admin."""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    return user

@availability_bp.route('/availability/<int:agent_id>', methods=['GET'])
@jwt_required()
def get_agent_availability(agent_id):
    """Get agent availability for a date range."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Agents can only view their own availability, admins can view any
        if current_user.role == 'agent' and current_user.id != agent_id:
            return jsonify({'error': 'Access denied'}), 403
        
        # Get date range from query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date:
            # Default to current week
            today = date.today()
            start_date = today - timedelta(days=today.weekday())
        else:
            start_date = parse(start_date).date()
        
        if not end_date:
            # Default to 4 weeks from start
            end_date = start_date + timedelta(weeks=4)
        else:
            end_date = parse(end_date).date()
        
        # Query availability
        availability = AgentAvailability.query.filter(
            AgentAvailability.agent_id == agent_id,
            AgentAvailability.date >= start_date,
            AgentAvailability.date <= end_date
        ).order_by(AgentAvailability.date).all()
        
        return jsonify({
            'agent_id': agent_id,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
            'availability': [avail.to_dict() for avail in availability]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@availability_bp.route('/availability', methods=['POST'])
@jwt_required()
def set_availability():
    """Set availability for date range."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['agent_id', 'start_date', 'end_date', 'is_available']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field} is required'}), 400
        
        agent_id = data['agent_id']
        
        # Agents can only set their own availability, admins can set any
        if current_user.role == 'agent' and current_user.id != agent_id:
            return jsonify({'error': 'Access denied'}), 403
        
        # Verify agent exists
        agent = User.query.filter_by(id=agent_id, role='agent').first()
        if not agent:
            return jsonify({'error': 'Agent not found'}), 404
        
        start_date = parse(data['start_date']).date()
        end_date = parse(data['end_date']).date()
        is_available = data['is_available']
        is_away = data.get('is_away', False)
        notes = data.get('notes')
        
        # Create or update availability for each date in range
        current_date = start_date
        updated_dates = []
        
        while current_date <= end_date:
            # Check if availability already exists
            existing = AgentAvailability.query.filter_by(
                agent_id=agent_id,
                date=current_date
            ).first()
            
            if existing:
                # Update existing
                existing.is_available = is_available
                existing.is_away = is_away
                existing.notes = notes
                existing.updated_at = datetime.utcnow()
            else:
                # Create new
                availability = AgentAvailability(
                    agent_id=agent_id,
                    date=current_date,
                    is_available=is_available,
                    is_away=is_away,
                    notes=notes
                )
                db.session.add(availability)
            
            updated_dates.append(current_date.isoformat())
            current_date += timedelta(days=1)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Availability updated successfully',
            'agent_id': agent_id,
            'updated_dates': updated_dates
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@availability_bp.route('/availability/<int:availability_id>', methods=['PUT'])
@jwt_required()
def update_availability(availability_id):
    """Update specific availability record."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        availability = AgentAvailability.query.get_or_404(availability_id)
        
        # Agents can only update their own availability, admins can update any
        if current_user.role == 'agent' and current_user.id != availability.agent_id:
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Update fields
        if 'is_available' in data:
            availability.is_available = data['is_available']
        if 'is_away' in data:
            availability.is_away = data['is_away']
        if 'notes' in data:
            availability.notes = data['notes']
        
        availability.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Availability updated successfully',
            'availability': availability.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@availability_bp.route('/availability/<int:availability_id>', methods=['DELETE'])
@jwt_required()
def delete_availability(availability_id):
    """Delete specific availability record."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        availability = AgentAvailability.query.get_or_404(availability_id)
        
        # Agents can only delete their own availability, admins can delete any
        if current_user.role == 'agent' and current_user.id != availability.agent_id:
            return jsonify({'error': 'Access denied'}), 403
        
        db.session.delete(availability)
        db.session.commit()
        
        return jsonify({'message': 'Availability deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@availability_bp.route('/availability/toggle/<int:agent_id>', methods=['POST'])
@jwt_required()
def toggle_daily_availability(agent_id):
    """Toggle agent availability for today."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Agents can only toggle their own availability
        if current_user.role == 'agent' and current_user.id != agent_id:
            return jsonify({'error': 'Access denied'}), 403
        
        # Verify agent exists
        agent = User.query.filter_by(id=agent_id, role='agent').first()
        if not agent:
            return jsonify({'error': 'Agent not found'}), 404
        
        today = date.today()
        
        # Get or create today's availability
        availability = AgentAvailability.query.filter_by(
            agent_id=agent_id,
            date=today
        ).first()
        
        if availability:
            # Toggle existing
            availability.is_available = not availability.is_available
            availability.updated_at = datetime.utcnow()
        else:
            # Create new as available
            availability = AgentAvailability(
                agent_id=agent_id,
                date=today,
                is_available=True,
                is_away=False
            )
            db.session.add(availability)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Availability toggled successfully',
            'availability': availability.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@availability_bp.route('/agents/available', methods=['GET'])
@jwt_required()
def get_available_agents():
    """Get list of available agents for a specific date."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Only admins can view all available agents
        if current_user.role != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        # Get date from query parameter
        target_date = request.args.get('date')
        if not target_date:
            target_date = date.today()
        else:
            target_date = parse(target_date).date()
        
        # Query available agents for the date
        available_agents = db.session.query(User, AgentAvailability).join(
            AgentAvailability, User.id == AgentAvailability.agent_id
        ).filter(
            User.role == 'agent',
            AgentAvailability.date == target_date,
            AgentAvailability.is_available == True,
            AgentAvailability.is_away == False
        ).all()
        
        result = []
        for user, availability in available_agents:
            agent_data = user.to_dict()
            agent_data['availability'] = availability.to_dict()
            result.append(agent_data)
        
        return jsonify({
            'date': target_date.isoformat(),
            'available_agents': result
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

