from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, Notification, db
from pyfcm import FCMNotification
import os

notifications_bp = Blueprint('notifications', __name__)

# Initialize FCM (you'll need to set FCM_SERVER_KEY environment variable)
FCM_SERVER_KEY = os.environ.get('FCM_SERVER_KEY')
if FCM_SERVER_KEY:
    push_service = FCMNotification(api_key=FCM_SERVER_KEY)
else:
    push_service = None
    print("Warning: FCM_SERVER_KEY not set. Push notifications will not work.")

def require_agent_or_admin():
    """Ensure user is an agent or admin."""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    return user

@notifications_bp.route('/notifications', methods=['GET'])
@jwt_required()
def get_notifications():
    """Get user notifications."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get query parameters
        is_read = request.args.get('is_read')
        notification_type = request.args.get('type')
        limit = request.args.get('limit', 50, type=int)
        
        # Build query
        query = Notification.query.filter_by(user_id=current_user.id)
        
        if is_read is not None:
            is_read_bool = is_read.lower() == 'true'
            query = query.filter(Notification.is_read == is_read_bool)
        
        if notification_type:
            query = query.filter(Notification.type == notification_type)
        
        notifications = query.order_by(Notification.sent_at.desc()).limit(limit).all()
        
        return jsonify({
            'notifications': [notification.to_dict() for notification in notifications]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/<int:notification_id>/read', methods=['PUT'])
@jwt_required()
def mark_notification_read(notification_id):
    """Mark notification as read."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        notification = Notification.query.filter_by(
            id=notification_id,
            user_id=current_user.id
        ).first()
        
        if not notification:
            return jsonify({'error': 'Notification not found'}), 404
        
        notification.is_read = True
        db.session.commit()
        
        return jsonify({
            'message': 'Notification marked as read',
            'notification': notification.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/mark-all-read', methods=['PUT'])
@jwt_required()
def mark_all_notifications_read():
    """Mark all notifications as read."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        updated_count = Notification.query.filter_by(
            user_id=current_user.id,
            is_read=False
        ).update({'is_read': True})
        
        db.session.commit()
        
        return jsonify({
            'message': f'{updated_count} notifications marked as read'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/send', methods=['POST'])
@jwt_required()
def send_notification():
    """Send push notification (admin only)."""
    try:
        current_user = require_agent_or_admin()
        if not current_user or current_user.role != 'admin':
            return jsonify({'error': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['user_ids', 'title', 'message']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        user_ids = data['user_ids']
        title = data['title']
        message = data['message']
        notification_type = data.get('type', 'general')
        job_id = data.get('job_id')
        
        # Get users and their FCM tokens
        users = User.query.filter(User.id.in_(user_ids)).all()
        
        sent_count = 0
        failed_count = 0
        
        for user in users:
            # Create notification record
            notification = Notification(
                user_id=user.id,
                title=title,
                message=message,
                type=notification_type,
                job_id=job_id
            )
            db.session.add(notification)
            
            # Send push notification if FCM token exists
            if user.fcm_token and push_service:
                try:
                    result = push_service.notify_single_device(
                        registration_id=user.fcm_token,
                        message_title=title,
                        message_body=message,
                        data_message={
                            'type': notification_type,
                            'job_id': str(job_id) if job_id else None,
                            'notification_id': str(notification.id)
                        }
                    )
                    
                    if result.get('success'):
                        sent_count += 1
                    else:
                        failed_count += 1
                        print(f"Failed to send push notification to user {user.id}: {result}")
                        
                except Exception as push_error:
                    failed_count += 1
                    print(f"Push notification error for user {user.id}: {str(push_error)}")
            else:
                # No FCM token or service not configured
                failed_count += 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'Notifications processed',
            'sent_count': sent_count,
            'failed_count': failed_count,
            'total_users': len(users)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/fcm-token', methods=['POST'])
@jwt_required()
def update_fcm_token():
    """Update user's FCM token."""
    try:
        current_user = require_agent_or_admin()
        if not current_user:
            return jsonify({'error': 'User not found'}), 404
        
        data = request.get_json()
        fcm_token = data.get('fcm_token')
        
        if not fcm_token:
            return jsonify({'error': 'fcm_token is required'}), 400
        
        current_user.fcm_token = fcm_token
        db.session.commit()
        
        return jsonify({'message': 'FCM token updated successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

def send_push_notification(user_id, title, message, notification_type='general', job_id=None):
    """Helper function to send push notification to a specific user."""
    try:
        user = User.query.get(user_id)
        if not user or not user.fcm_token or not push_service:
            return False
        
        # Create notification record
        notification = Notification(
            user_id=user_id,
            title=title,
            message=message,
            type=notification_type,
            job_id=job_id
        )
        db.session.add(notification)
        
        # Send push notification
        result = push_service.notify_single_device(
            registration_id=user.fcm_token,
            message_title=title,
            message_body=message,
            data_message={
                'type': notification_type,
                'job_id': str(job_id) if job_id else None,
                'notification_id': str(notification.id)
            }
        )
        
        db.session.commit()
        return result.get('success', False)
        
    except Exception as e:
        db.session.rollback()
        print(f"Error sending push notification: {str(e)}")
        return False

def send_push_notification_to_multiple(user_ids, title, message, notification_type='general', job_id=None):
    """Helper function to send push notification to multiple users."""
    try:
        users = User.query.filter(User.id.in_(user_ids)).all()
        fcm_tokens = [user.fcm_token for user in users if user.fcm_token]
        
        if not fcm_tokens or not push_service:
            return {'success': 0, 'failure': len(user_ids)}
        
        # Create notification records
        for user in users:
            notification = Notification(
                user_id=user.id,
                title=title,
                message=message,
                type=notification_type,
                job_id=job_id
            )
            db.session.add(notification)
        
        # Send push notifications
        result = push_service.notify_multiple_devices(
            registration_ids=fcm_tokens,
            message_title=title,
            message_body=message,
            data_message={
                'type': notification_type,
                'job_id': str(job_id) if job_id else None
            }
        )
        
        db.session.commit()
        return result
        
    except Exception as e:
        db.session.rollback()
        print(f"Error sending push notifications: {str(e)}")
        return {'success': 0, 'failure': len(user_ids)}

